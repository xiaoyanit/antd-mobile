# antd-mobile with nowa

basic antd-mobile proj demo with nowa

### Install & Start

```shell
npm i
npm start
```

open http://localhost:8000/

### Build

```
npm run build
```
