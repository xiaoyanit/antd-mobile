import React from 'react';
import {createForm} from 'rc-form';
import moment from 'moment'; // moment.min ~= 48kb
import {district} from 'antd-mobile-demo-data';

import {
  Picker,
  Tabs,
  DatePicker,
  List,
  Checkbox,
  Button,
  Steps,
  NavBar,
  InputItem,
  WhiteSpace
} from 'antd-mobile';
import enUs from 'antd-mobile/lib/date-picker/locale/en_US';
import DrawerTest from './Drawer';
const CheckboxItem = Checkbox.CheckboxItem;
const TabPane = Tabs.TabPane;

function callback(key) {
  console.log('onChange', key);

 
}
function handleTabClick(key) {
  console.log('onTabClick', key);
}

// 如果不是使用 List.Item 作为 children
{/*
const CustomChildren = (props) => {
  return (
    <div
      onClick={props.onClick}
      style={{
      backgroundColor: '#fff',
      height: '0.9rem',
      lineHeight: '0.9rem',
      padding: '0 0.3rem'
    }}>
      {props.children}
      <span style={{
        float: 'right'
      }}>{props.extra}</span>
    </div>
  );
};
*/}
class Test extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      pickerValue: [],
      // pickerValue: ['340000', '340800', '340824'] dpValue: moment(),
      dpValue: null
    };
  }

  render() {
  //  const {getFieldProps} = this.props.form;
   // const {pickerValue, dpValue} = this.state;
    return (


        <div>
          <Tabs defaultActiveKey="1" pageSize={3} onChange={callback} onTabClick={handleTabClick}>
            <TabPane tab="销售人员" key="1">
              <div
                style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                height: '5rem',
                backgroundColor: '#fff'
              }}>
                销售人员
              </div>
            </TabPane>
            <TabPane defaultActiveKey="1" tab="选项卡二" key="2">
              <div
                style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                height: '5rem',
                backgroundColor: '#fff'
              }}>
               非销售人员
              </div>
            </TabPane>
            
          </Tabs>
          <WhiteSpace/>
        </div>

   
    );
  }
}

export default createForm()(Test);
if ('addEventListener' in document) {
  window.addEventListener('load', function() {
    FastClick.attach(document.body);
  }, false);
}